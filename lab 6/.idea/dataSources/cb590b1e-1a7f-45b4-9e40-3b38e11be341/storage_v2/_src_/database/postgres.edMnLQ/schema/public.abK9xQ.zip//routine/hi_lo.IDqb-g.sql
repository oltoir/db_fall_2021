create function hi_lo(val integer, val1 integer, OUT hi integer, OUT lo integer) returns record
    language plpgsql
as
$$
begin
        hi = greatest(val, val1);
        lo = least(val, val1);
    end;
$$;

alter function hi_lo(integer, integer, out integer, out integer) owner to postgres;

