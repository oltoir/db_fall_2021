create function inc(val integer, val1 integer) returns integer
    language plpgsql
as
$$
begin
        return val + val1;
    end;
$$;

alter function inc(integer, integer) owner to postgres;

