create view dealers_sale(dealer_id, count, avg, sum) as
SELECT sell.dealer_id,
       count(sell.dealer_id) AS count,
       avg(sell.amount)      AS avg,
       sum(sell.amount)      AS sum
FROM sell
GROUP BY sell.dealer_id
ORDER BY sell.dealer_id;

alter table dealers_sale
    owner to postgres;

