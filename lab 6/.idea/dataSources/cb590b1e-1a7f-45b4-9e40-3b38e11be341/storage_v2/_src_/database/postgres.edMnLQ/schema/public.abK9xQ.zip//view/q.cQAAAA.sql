create view q(cit) as
SELECT w.cit
FROM (SELECT sum(sell.amount) AS sales,
             dealer.location  AS loc
      FROM sell
               JOIN dealer ON sell.dealer_id = dealer.id
      GROUP BY dealer.location) q
         JOIN (SELECT client.city      AS cit,
                      sum(sell.amount) AS expences
               FROM client
                        JOIN sell ON client.id = sell.client_id
               GROUP BY client.city) w ON w.expences > q.sales AND q.loc::text = w.cit::text;

alter table q
    owner to postgres;

