create function inc(val integer) returns boolean
    language plpgsql
as
$$
begin
        if val % 2 = 0
            then return true;
        else
            return false;
        end if;
    end;
$$;

alter function inc(integer) owner to postgres;

