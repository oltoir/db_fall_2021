create view earnings(location, sum) as
SELECT q.location,
       sum(q.total) AS sum
FROM (SELECT d.location,
             sum(sell.amount) * d.charge AS total
      FROM sell
               JOIN dealer d ON sell.dealer_id = d.id
      GROUP BY d.location, d.charge) q
GROUP BY q.location
HAVING q.location::text = q.location::text;

alter table earnings
    owner to postgres;

