create function tr1() returns trigger
    language plpgsql
as
$$
BEGIN
     NEW.age = extract(year from age(old.date_of_birth));
     select now();
     RETURN NEW;
END;
$$;

alter function tr1() owner to postgres;

