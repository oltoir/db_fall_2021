create view each_city(city, count, sum, avg) as
SELECT client.city,
       count(client.city) AS count,
       sum(s.amount)      AS sum,
       avg(s.amount)      AS avg
FROM client
         JOIN sell s ON client.id = s.client_id
GROUP BY client.city;

alter table each_city
    owner to postgres;

