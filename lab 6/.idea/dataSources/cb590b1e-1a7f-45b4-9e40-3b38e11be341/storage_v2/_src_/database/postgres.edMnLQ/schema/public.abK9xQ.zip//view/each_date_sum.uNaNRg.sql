create view each_date_sum(date, sum) as
SELECT sell.date,
       sum(sell.amount) AS sum
FROM sell
GROUP BY sell.date
ORDER BY (sum(sell.amount)) DESC
LIMIT 5;

alter table each_date_sum
    owner to postgres;

