create view city_dealer(location, count, sum, avg) as
SELECT dealer.location,
       count(sell.id)   AS count,
       sum(sell.amount) AS sum,
       avg(sell.amount) AS avg
FROM sell
         JOIN dealer ON sell.dealer_id = dealer.id
GROUP BY dealer.location;

alter table city_dealer
    owner to postgres;

