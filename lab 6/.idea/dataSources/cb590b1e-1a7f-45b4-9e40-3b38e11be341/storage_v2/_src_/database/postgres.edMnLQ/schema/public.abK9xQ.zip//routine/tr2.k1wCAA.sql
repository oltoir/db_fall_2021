create function tr2() returns trigger
    language plpgsql
as
$$
BEGIN
     NEW.salary = old.salary * 0.12 + old.salary;
     RETURN NEW;
END;
$$;

alter function tr2() owner to postgres;

