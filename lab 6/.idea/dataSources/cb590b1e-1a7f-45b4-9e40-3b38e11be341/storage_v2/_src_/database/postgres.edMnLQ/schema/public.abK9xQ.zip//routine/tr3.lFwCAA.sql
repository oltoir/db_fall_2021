create function tr3() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.salary = old.salary * 0.12 + old.salary;
    new.last_date = current_timestamp;
    return new;
END;
$$;

alter function tr3() owner to postgres;

