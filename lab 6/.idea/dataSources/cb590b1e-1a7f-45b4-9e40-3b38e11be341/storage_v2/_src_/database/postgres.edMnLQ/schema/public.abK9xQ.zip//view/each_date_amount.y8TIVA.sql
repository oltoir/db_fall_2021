create view each_date_amount(date, count, avg, sum) as
SELECT sell.date,
       count(DISTINCT sell.client_id) AS count,
       avg(sell.amount)               AS avg,
       sum(sell.amount)               AS sum
FROM sell
GROUP BY sell.date
ORDER BY sell.date;

alter table each_date_amount
    owner to postgres;

